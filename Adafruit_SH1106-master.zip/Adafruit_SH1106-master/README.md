# Adafruit_SH1106

Modified Adafruit SSD1306 library for the 1.3" OLED I2C screen. Tested to work on I2C version only.
See https://www.teachmemicro.com/1-3-oled-i2c-arduino-esp8266-tutorial for demonstration.
